var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var bot_exports = {};
__export(bot_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(bot_exports);
var import_blobs = require("@netlify/blobs");
const STATUS = Object.freeze({
  NEW: "new",
  ANSWERING: "answering",
  PENDING: "pending",
  APPROVED: "approved",
  REJECTED: "rejected"
});
const COMMANDS = Object.freeze({
  APPROVE: "/approve",
  REJECT: "/reject",
  HELP: "/help",
  ID: "/id",
  START: "/start",
  START_ALT: "start"
});
const CALLBACK_ACTIONS = Object.freeze(["approve", "reject"]);
const METHOD = Object.freeze({
  SEND_MESSAGE: "sendMessage"
});
const ERROR_MESSAGES = Object.freeze({
  BOT_TOKEN: "BOT_TOKEN not configured",
  METHOD_NOT_ALLOWED: "Method not allowed"
});
const TELEGRAM_API_BASE = "https://api.telegram.org/bot";
const env = {
  botToken: () => process.env.BOT_TOKEN,
  adminChatId: () => process.env.ADMIN_CHAT_ID || "",
  inviteLink: () => process.env.INVITE_LINK || "[\u0441\u0441\u044B\u043B\u043A\u0430]",
  reportTime: () => process.env.REPORT_TIME || "21:00",
  reapplyDays: () => Number(process.env.REAPPLY_DAYS || 30)
};
const QUESTIONS = Object.freeze([
  {
    id: "identity",
    title: "\u0412\u043E\u043F\u0440\u043E\u0441 1 / \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u044F",
    text: "\u0421\u043A\u043E\u043B\u044C\u043A\u043E \u0442\u0435\u0431\u0435 \u043B\u0435\u0442 \u0438 \u0438\u0437 \u043A\u0430\u043A\u043E\u0433\u043E \u0442\u044B \u0433\u043E\u0440\u043E\u0434\u0430?\n\n\u0424\u043E\u0440\u043C\u0430\u0442: 28, \u041C\u043E\u0441\u043A\u0432\u0430"
  },
  {
    id: "failure",
    title: "\u0412\u043E\u043F\u0440\u043E\u0441 2 / \u043A\u043E\u043D\u043A\u0440\u0435\u0442\u043D\u044B\u0439 \u043F\u0440\u043E\u0432\u0430\u043B",
    text: '\u041D\u0430\u0437\u043E\u0432\u0438 \u043E\u0434\u043D\u043E \u0434\u0435\u043B\u043E, \u043A\u043E\u0442\u043E\u0440\u043E\u0435 \u0442\u044B \u043D\u0430\u0447\u0438\u043D\u0430\u043B \u0431\u043E\u043B\u044C\u0448\u0435 \u0434\u0432\u0443\u0445 \u0440\u0430\u0437 \u0438 \u0442\u0430\u043A \u0438 \u043D\u0435 \u0434\u043E\u0432\u0435\u043B \u0434\u043E \u043A\u043E\u043D\u0446\u0430.\n\n\u041A\u043E\u043D\u043A\u0440\u0435\u0442\u043D\u043E. \u041D\u0435 "\u0440\u0430\u0437\u0432\u0438\u0432\u0430\u0442\u044C\u0441\u044F" \u0438 \u043D\u0435 "\u0437\u0430\u043D\u044F\u0442\u044C\u0441\u044F \u0441\u043F\u043E\u0440\u0442\u043E\u043C".\n\u041F\u0440\u043E\u0435\u043A\u0442, \u043F\u0440\u043E\u0434\u0443\u043A\u0442, \u043D\u0430\u0432\u044B\u043A, \u0431\u0438\u0437\u043D\u0435\u0441, \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442, \u0442\u0435\u043B\u043E, \u0434\u0435\u043D\u044C\u0433\u0438.'
  },
  {
    id: "reason",
    title: "\u0412\u043E\u043F\u0440\u043E\u0441 3 / \u043D\u0430\u0441\u0442\u043E\u044F\u0449\u0430\u044F \u043F\u0440\u0438\u0447\u0438\u043D\u0430",
    text: '\u041F\u043E\u0447\u0435\u043C\u0443 \u0442\u044B \u0435\u0433\u043E \u043D\u0435 \u0434\u043E\u0434\u0435\u043B\u0430\u043B?\n\n\u0422\u043E\u043B\u044C\u043A\u043E \u043E\u0434\u043D\u0430 \u043F\u0440\u0438\u0447\u0438\u043D\u0430. \u041D\u0430\u0441\u0442\u043E\u044F\u0449\u0430\u044F.\n\u041D\u0435 "\u043D\u0435 \u0431\u044B\u043B\u043E \u0432\u0440\u0435\u043C\u0435\u043D\u0438".\n\n\u0427\u0442\u043E \u0441\u0442\u043E\u044F\u043B\u043E \u0437\u0430 \u044D\u0442\u0438\u043C \u043D\u0430 \u0441\u0430\u043C\u043E\u043C \u0434\u0435\u043B\u0435?'
  },
  {
    id: "current_action",
    title: "\u0412\u043E\u043F\u0440\u043E\u0441 4 / \u0442\u0435\u043A\u0443\u0449\u0430\u044F \u0441\u0438\u0442\u0443\u0430\u0446\u0438\u044F",
    text: "\u0427\u0442\u043E \u0442\u044B \u0434\u0435\u043B\u0430\u0435\u0448\u044C \u043F\u0440\u044F\u043C\u043E \u0441\u0435\u0439\u0447\u0430\u0441, \u0447\u0442\u043E\u0431\u044B \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u044C \u044D\u0442\u0443 \u0441\u0438\u0442\u0443\u0430\u0446\u0438\u044E?\n\n\u041A\u043E\u043D\u043A\u0440\u0435\u0442\u043D\u044B\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F.\n\u0415\u0441\u043B\u0438 \u043D\u0438\u0447\u0435\u0433\u043E \u2014 \u0442\u0430\u043A \u0438 \u043D\u0430\u043F\u0438\u0448\u0438."
  },
  {
    id: "rules",
    title: "\u0412\u043E\u043F\u0440\u043E\u0441 5 / \u0433\u043E\u0442\u043E\u0432\u043D\u043E\u0441\u0442\u044C \u043A \u043F\u0440\u0430\u0432\u0438\u043B\u0430\u043C",
    text: "\u0412 \u043A\u0430\u043D\u0430\u043B\u0435 \u0435\u0441\u0442\u044C \u043E\u0434\u043D\u043E \u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0435 \u0443\u0441\u043B\u043E\u0432\u0438\u0435: \u0435\u0436\u0435\u0434\u043D\u0435\u0432\u043D\u044B\u0439 \u043E\u0442\u0447\u0435\u0442 \u0432 {reportTime} \u2014 \u0447\u0442\u043E \u043A\u043E\u043D\u043A\u0440\u0435\u0442\u043D\u043E \u0442\u044B \u0441\u0434\u0435\u043B\u0430\u043B \u0437\u0430 \u0434\u0435\u043D\u044C.\n\n\u041F\u0440\u043E\u043F\u0443\u0441\u043A \u0431\u0435\u0437 \u043F\u0440\u0435\u0434\u0443\u043F\u0440\u0435\u0436\u0434\u0435\u043D\u0438\u044F = \u0432\u044B\u0445\u043E\u0434 \u0438\u0437 \u0430\u043A\u0442\u0438\u0432\u043D\u043E\u0433\u043E \u044F\u0434\u0440\u0430.\n\n\u0422\u044B \u0433\u043E\u0442\u043E\u0432 \u043A \u044D\u0442\u043E\u043C\u0443?\n\n\u041E\u0442\u0432\u0435\u0442\u044C: \u0414\u0430 / \u041D\u0435\u0442 / \u041D\u0435 \u0443\u0432\u0435\u0440\u0435\u043D"
  }
]);
const log = {
  error: (context, err) => {
    console.error(
      JSON.stringify({
        level: "error",
        context,
        message: err?.message,
        stack: err?.stack
      })
    );
  }
};
const createApplicationRepository = (store) => {
  const KEY = "applications";
  const read = async () => {
    try {
      const raw = await store.get(KEY, { type: "text" });
      return raw ? JSON.parse(raw) : { offset: 0, users: {} };
    } catch {
      return { offset: 0, users: {} };
    }
  };
  const save = async (data) => {
    await store.set(KEY, JSON.stringify(data));
  };
  return { read, save };
};
const createTelegramClient = () => {
  const call = async (method, body) => {
    const url = `${TELEGRAM_API_BASE}${env.botToken()}/${method}`;
    const res = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body)
    });
    const payload = await res.json().catch(() => null);
    if (!res.ok || !payload?.ok) {
      log.error("telegram_api", new Error(`API ${method} failed: ${res.status}`));
    }
    return payload;
  };
  const sendMessage = (chatId, text, extra = {}) => call(METHOD.SEND_MESSAGE, {
    chat_id: chatId,
    text,
    disable_web_page_preview: true,
    ...extra
  });
  return { sendMessage };
};
const buildCopy = () => {
  const link = env.inviteLink();
  const time = env.reportTime();
  const days = env.reapplyDays();
  return {
    start: "\u0425\u043E\u0440\u043E\u0448\u043E. \u0422\u044B \u0437\u0434\u0435\u0441\u044C.\n\n\u042D\u0442\u043E \u043D\u0435 \u043A\u0430\u043D\u0430\u043B \u0434\u043B\u044F \u0432\u0441\u0435\u0445.\n\u042D\u0442\u043E \u043D\u0435 \u043C\u0435\u0441\u0442\u043E, \u0433\u0434\u0435 \u0442\u0435\u0431\u044F \u0431\u0443\u0434\u0443\u0442 \u0445\u0432\u0430\u043B\u0438\u0442\u044C \u0437\u0430 \u043F\u043E\u043F\u044B\u0442\u043A\u0438.\n\n\u0417\u0434\u0435\u0441\u044C \u043E\u0434\u0438\u043D \u0441\u0442\u0430\u043D\u0434\u0430\u0440\u0442: \u0434\u0435\u043B\u0430\u0435\u0448\u044C \u0438\u043B\u0438 \u043D\u0435\u0442.\n\n\u041F\u0435\u0440\u0435\u0434 \u0442\u0435\u043C \u043A\u0430\u043A \u044F \u0434\u0430\u043C \u0442\u0435\u0431\u0435 \u0434\u043E\u0441\u0442\u0443\u043F \u2014 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0432\u043E\u043F\u0440\u043E\u0441\u043E\u0432.\n\u041E\u0442\u0432\u0435\u0447\u0430\u0439 \u0447\u0435\u0441\u0442\u043D\u043E. \u041D\u0435 \u0434\u043B\u044F \u043C\u0435\u043D\u044F. \u0414\u043B\u044F \u0441\u0435\u0431\u044F.\n\n\u0415\u0441\u043B\u0438 \u043E\u0442\u0432\u0435\u0442\u044B \u043D\u0435 \u043F\u0440\u043E\u0439\u0434\u0443\u0442 \u043C\u043E\u0434\u0435\u0440\u0430\u0446\u0438\u044E \u2014 \u0442\u044B \u043F\u043E\u043B\u0443\u0447\u0438\u0448\u044C \u043E\u0442\u043A\u0430\u0437 \u0431\u0435\u0437 \u043E\u0431\u044A\u044F\u0441\u043D\u0435\u043D\u0438\u0439.\n\n\u041D\u0430\u0447\u043D\u0435\u043C.",
    alreadyPending: "\u0422\u0432\u043E\u044F \u0437\u0430\u044F\u0432\u043A\u0430 \u0443\u0436\u0435 \u043D\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0435.\n\n\u041D\u0435 \u043D\u0430\u0434\u043E \u0434\u0435\u0440\u0433\u0430\u0442\u044C \u0434\u0432\u0435\u0440\u044C. \u041E\u0442\u0432\u0435\u0442 \u043F\u0440\u0438\u0434\u0435\u0442 \u043F\u043E\u0441\u043B\u0435 \u043C\u043E\u0434\u0435\u0440\u0430\u0446\u0438\u0438.",
    alreadyApproved: `\u0422\u044B \u0443\u0436\u0435 \u043F\u0440\u0438\u043D\u044F\u0442.

\u0421\u0441\u044B\u043B\u043A\u0430 \u043D\u0430 \u043A\u0430\u043D\u0430\u043B: ${link}

\u041F\u0435\u0440\u0432\u044B\u0439 \u043E\u0442\u0447\u0435\u0442 \u2014 \u0441\u0435\u0433\u043E\u0434\u043D\u044F \u0432 ${time}. \u041E\u0434\u0438\u043D \u043F\u0443\u043D\u043A\u0442. \u041A\u043E\u043D\u043A\u0440\u0435\u0442\u043D\u044B\u0439.`,
    rejected: `\u0417\u0430\u044F\u0432\u043A\u0430 \u043E\u0442\u043A\u043B\u043E\u043D\u0435\u043D\u0430.

\u0411\u0435\u0437 \u043E\u0431\u0438\u0434 \u0438 \u0431\u0435\u0437 \u043E\u0431\u044A\u044F\u0441\u043D\u0435\u043D\u0438\u0439 \u2014 \u044D\u0442\u043E \u0447\u0430\u0441\u0442\u044C \u0443\u0441\u043B\u043E\u0432\u0438\u0439, \u043A\u043E\u0442\u043E\u0440\u044B\u0435 \u0442\u044B \u043F\u0440\u0438\u043D\u044F\u043B.

\u0415\u0441\u043B\u0438 \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u0441\u044F \u0447\u0442\u043E-\u0442\u043E \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0435, \u043C\u043E\u0436\u0435\u0448\u044C \u043F\u043E\u0434\u0430\u0442\u044C \u0441\u043D\u043E\u0432\u0430 \u0447\u0435\u0440\u0435\u0437 ${days} \u0434\u043D\u0435\u0439.`,
    submitted: "\u0417\u0430\u044F\u0432\u043A\u0430 \u043F\u0440\u0438\u043D\u044F\u0442\u0430.\n\n\u0415\u0441\u043B\u0438 \u043E\u0442\u0432\u0435\u0442\u044B \u0436\u0438\u0432\u044B\u0435 \u2014 \u043F\u043E\u043B\u0443\u0447\u0438\u0448\u044C \u0432\u0445\u043E\u0434.\n\u0415\u0441\u043B\u0438 \u0442\u0430\u043C \u0442\u0443\u043C\u0430\u043D \u0438 \u043F\u043E\u0437\u0430 \u2014 \u043D\u0435\u0442.\n\n\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0434\u043E 24 \u0447\u0430\u0441\u043E\u0432.",
    approved: `\u0417\u0430\u044F\u0432\u043A\u0430 \u0440\u0430\u0441\u0441\u043C\u043E\u0442\u0440\u0435\u043D\u0430.

\u0422\u044B \u043F\u0440\u0438\u043D\u044F\u0442.

\u041E\u0434\u043D\u043E \u0443\u0441\u043B\u043E\u0432\u0438\u0435: \u043F\u0435\u0440\u0432\u044B\u0439 \u043E\u0442\u0447\u0435\u0442 \u2014 \u0441\u0435\u0433\u043E\u0434\u043D\u044F \u0432 ${time}.
\u0427\u0442\u043E \u0441\u0434\u0435\u043B\u0430\u043B \u0441\u0435\u0433\u043E\u0434\u043D\u044F.
\u041E\u0434\u0438\u043D \u043F\u0443\u043D\u043A\u0442. \u041A\u043E\u043D\u043A\u0440\u0435\u0442\u043D\u044B\u0439.

\u042D\u0442\u043E \u0442\u0432\u043E\u0439 \u043F\u0435\u0440\u0432\u044B\u0439 \u0442\u0435\u0441\u0442.

\u0421\u0441\u044B\u043B\u043A\u0430 \u043D\u0430 \u043A\u0430\u043D\u0430\u043B: ${link}

\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442 24 \u0447\u0430\u0441\u0430.`
  };
};
const createApplicationService = (repo, tg) => {
  const canReapply = (user) => {
    if (!user.rejectedAt) return true;
    const waitMs = env.reapplyDays() * 24 * 60 * 60 * 1e3;
    return Date.now() - new Date(user.rejectedAt).getTime() >= waitMs;
  };
  const isAdmin = (chatId) => {
    const admin = env.adminChatId();
    return admin && String(chatId) === String(admin);
  };
  const getOrCreateUser = (db, chatId, from = {}) => {
    if (!db.users[chatId]) {
      db.users[chatId] = {
        chatId,
        status: STATUS.NEW,
        step: 0,
        answers: {},
        username: from.username || "",
        name: [from.first_name, from.last_name].filter(Boolean).join(" "),
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
    }
    return db.users[chatId];
  };
  const askQuestion = async (chatId, index) => {
    const q = QUESTIONS[index];
    const text = q.text.replace("{reportTime}", env.reportTime());
    await tg.sendMessage(chatId, `${q.title}

${text}`);
  };
  const sendApplicationToAdmin = async (chatId, user) => {
    const adminChatId = env.adminChatId();
    if (!adminChatId) return;
    const lines = [
      "\u041D\u043E\u0432\u0430\u044F \u0437\u0430\u044F\u0432\u043A\u0430.",
      "",
      `ID: ${chatId}`,
      `Username: ${user.username ? "@" + user.username : "\u043D\u0435\u0442"}`,
      `\u0418\u043C\u044F: ${user.name || "\u043D\u0435\u0442"}`,
      "",
      `1. ${QUESTIONS[0].title}`,
      user.answers.identity || "-",
      "",
      `2. ${QUESTIONS[1].title}`,
      user.answers.failure || "-",
      "",
      `3. ${QUESTIONS[2].title}`,
      user.answers.reason || "-",
      "",
      `4. ${QUESTIONS[3].title}`,
      user.answers.current_action || "-",
      "",
      `5. ${QUESTIONS[4].title}`,
      user.answers.rules || "-"
    ];
    await tg.sendMessage(adminChatId, lines.join("\n"), {
      reply_markup: {
        inline_keyboard: [
          [
            { text: "\u041F\u0440\u0438\u043D\u044F\u0442\u044C", callback_data: `approve:${chatId}` },
            { text: "\u041E\u0442\u043A\u043B\u043E\u043D\u0438\u0442\u044C", callback_data: `reject:${chatId}` }
          ]
        ]
      }
    });
  };
  const startApplication = async (msg) => {
    const chatId = String(msg.chat.id);
    const db = await repo.read();
    const user = getOrCreateUser(db, chatId, msg.from);
    const copy = buildCopy();
    if (user.status === STATUS.PENDING) {
      await tg.sendMessage(chatId, copy.alreadyPending);
      return;
    }
    if (user.status === STATUS.APPROVED) {
      await tg.sendMessage(chatId, copy.alreadyApproved);
      return;
    }
    if (user.status === STATUS.REJECTED && !canReapply(user)) {
      await tg.sendMessage(chatId, copy.rejected);
      return;
    }
    const now = (/* @__PURE__ */ new Date()).toISOString();
    user.status = STATUS.ANSWERING;
    user.step = 0;
    user.answers = {};
    user.startedAt = now;
    user.updatedAt = now;
    await repo.save(db);
    await tg.sendMessage(chatId, copy.start);
    await askQuestion(chatId, 0);
  };
  const continueApplication = async (msg) => {
    const chatId = String(msg.chat.id);
    const text = String(msg.text || "").trim();
    const db = await repo.read();
    const user = db.users[chatId];
    const copy = buildCopy();
    if (!user || user.status === STATUS.PENDING) {
      await tg.sendMessage(chatId, copy.alreadyPending);
      return;
    }
    if (user.status === STATUS.APPROVED) {
      await tg.sendMessage(chatId, copy.alreadyApproved);
      return;
    }
    if (user.status !== STATUS.ANSWERING) {
      await tg.sendMessage(
        chatId,
        "\u0427\u0442\u043E\u0431\u044B \u043F\u043E\u0434\u0430\u0442\u044C \u0437\u0430\u044F\u0432\u043A\u0443, \u043D\u0430\u043F\u0438\u0448\u0438 /start.\n\n\u0411\u0435\u0437 \u0430\u043D\u043A\u0435\u0442\u044B \u0432\u0445\u043E\u0434\u0430 \u043D\u0435\u0442."
      );
      return;
    }
    if (!text) {
      await tg.sendMessage(chatId, "\u0422\u0435\u043A\u0441\u0442\u043E\u043C. \u041A\u043E\u0440\u043E\u0442\u043A\u043E \u0438 \u043A\u043E\u043D\u043A\u0440\u0435\u0442\u043D\u043E.");
      return;
    }
    const question = QUESTIONS[user.step];
    user.answers[question.id] = text;
    user.step += 1;
    user.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    await repo.save(db);
    if (user.step < QUESTIONS.length) {
      await askQuestion(chatId, user.step);
      return;
    }
    await submitApplication(chatId, user, db);
  };
  const submitApplication = async (chatId, user, db) => {
    user.status = STATUS.PENDING;
    user.submittedAt = (/* @__PURE__ */ new Date()).toISOString();
    user.updatedAt = user.submittedAt;
    await repo.save(db);
    const copy = buildCopy();
    await tg.sendMessage(chatId, copy.submitted);
    await sendApplicationToAdmin(chatId, user);
  };
  const moderateApplication = async (targetChatId, action) => {
    const db = await repo.read();
    const user = db.users[String(targetChatId)];
    if (!user) return;
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const copy = buildCopy();
    const isApproved = action === "approve";
    user.status = isApproved ? STATUS.APPROVED : STATUS.REJECTED;
    if (isApproved) user.approvedAt = now;
    else user.rejectedAt = now;
    user.updatedAt = now;
    await repo.save(db);
    await tg.sendMessage(targetChatId, isApproved ? copy.approved : copy.rejected);
  };
  const handleCallback = async (callback) => {
    const data = String(callback.data || "");
    const fromChatId = String(callback.message?.chat?.id || "");
    if (!isAdmin(fromChatId)) return;
    const [action, targetChatId] = data.split(":");
    if (!targetChatId || !CALLBACK_ACTIONS.includes(action)) return;
    await moderateApplication(targetChatId, action);
  };
  const handleAdminCommand = async (text, action, adminChatId) => {
    const [, targetChatId] = text.split(/\s+/);
    if (!targetChatId) {
      await tg.sendMessage(adminChatId, `\u0424\u043E\u0440\u043C\u0430\u0442: /${action} <telegram_id>`);
      return;
    }
    await moderateApplication(targetChatId, action);
    const msg = action === "approve" ? "\u041E\u0434\u043E\u0431\u0440\u0435\u043D\u043E. \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C \u043F\u043E\u043B\u0443\u0447\u0438\u043B \u0441\u0441\u044B\u043B\u043A\u0443." : "\u041E\u0442\u043A\u043B\u043E\u043D\u0435\u043D\u043E. \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C \u043F\u043E\u043B\u0443\u0447\u0438\u043B \u0441\u0443\u0445\u043E\u0439 \u043E\u0442\u043A\u0430\u0437.";
    await tg.sendMessage(adminChatId, msg);
  };
  const handleMessage = async (msg) => {
    const chatId = String(msg.chat.id);
    const text = String(msg.text || "").trim();
    if (isAdmin(chatId) && text.startsWith(COMMANDS.APPROVE)) {
      await handleAdminCommand(text, "approve", chatId);
      return;
    }
    if (isAdmin(chatId) && text.startsWith(COMMANDS.REJECT)) {
      await handleAdminCommand(text, "reject", chatId);
      return;
    }
    if (text === COMMANDS.HELP) {
      const helpText = isAdmin(chatId) ? [
        "\u0410\u0434\u043C\u0438\u043D-\u043A\u043E\u043C\u0430\u043D\u0434\u044B:",
        "/approve <telegram_id> \u2014 \u043F\u0440\u0438\u043D\u044F\u0442\u044C",
        "/reject <telegram_id> \u2014 \u043E\u0442\u043A\u043B\u043E\u043D\u0438\u0442\u044C",
        "",
        "\u041C\u043E\u0436\u043D\u043E \u0442\u0430\u043A\u0436\u0435 \u043D\u0430\u0436\u0438\u043C\u0430\u0442\u044C \u043A\u043D\u043E\u043F\u043A\u0438 \u043F\u043E\u0434 \u0437\u0430\u044F\u0432\u043A\u043E\u0439."
      ].join("\n") : "\u041A\u043E\u043C\u0430\u043D\u0434\u044B: /start \u2014 \u043F\u043E\u0434\u0430\u0442\u044C \u0437\u0430\u044F\u0432\u043A\u0443.";
      await tg.sendMessage(chatId, helpText);
      return;
    }
    if (text === COMMANDS.ID) {
      await tg.sendMessage(
        chatId,
        `\u0422\u0432\u043E\u0439 chat id: ${chatId}

\u0423\u043A\u0430\u0436\u0438 \u0435\u0433\u043E \u0432 \u043F\u0435\u0440\u0435\u043C\u0435\u043D\u043D\u043E\u0439 ADMIN_CHAT_ID \u0432 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430\u0445 Netlify.`
      );
      return;
    }
    if (text === COMMANDS.START || text === COMMANDS.START_ALT) {
      await startApplication(msg);
      return;
    }
    await continueApplication(msg);
  };
  return { handleCallback, handleMessage };
};
const createHandler = () => {
  const store = (0, import_blobs.getStore)("bot-data");
  const repo = createApplicationRepository(store);
  const tg = createTelegramClient();
  const service = createApplicationService(repo, tg);
  return async (event) => {
    if (event.httpMethod !== "POST") {
      return { statusCode: 405, body: ERROR_MESSAGES.METHOD_NOT_ALLOWED };
    }
    if (!env.botToken()) {
      return { statusCode: 500, body: ERROR_MESSAGES.BOT_TOKEN };
    }
    try {
      const update = JSON.parse(event.body);
      if (update.callback_query) {
        await service.handleCallback(update.callback_query);
      } else if (update.message) {
        await service.handleMessage(update.message);
      }
      return { statusCode: 200, body: "OK" };
    } catch (err) {
      log.error("handler", err);
      return { statusCode: 200, body: "OK" };
    }
  };
};
const handler = createHandler();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
